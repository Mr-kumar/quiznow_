export class Exam {}
