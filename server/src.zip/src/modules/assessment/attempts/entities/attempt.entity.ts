export class Attempt {}
