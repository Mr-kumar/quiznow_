import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { adminSettingsApi } from "@/api/settings";
import { settingsKeys } from "@/api/query-keys";
import { parseApiError } from "@/lib/errors";
import { unwrap } from "@/lib/unwrap";
import type { AppSettings } from "@/api/settings";

// ─── Queries ──────────────────────────────────────────────────────────────────

export function useSettings() {
  return useQuery({
    queryKey: settingsKeys.all(),
    queryFn: async () => unwrap<AppSettings[]>(await adminSettingsApi.getAll()),
    staleTime: 1000 * 60 * 10, // settings change rarely
  });
}

export function useSettingsByCategory(category: string) {
  return useQuery({
    queryKey: [...settingsKeys.all(), "category", category] as const,
    queryFn: async () =>
      unwrap<AppSettings[]>(await adminSettingsApi.getByCategory(category)),
    enabled: !!category,
    staleTime: 1000 * 60 * 10,
  });
}

// ─── Mutations ────────────────────────────────────────────────────────────────

export function useUpdateSetting() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, value }: { id: string; value: string }) =>
      adminSettingsApi.update(id, value),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: settingsKeys.all() });
      toast.success("Setting saved");
    },
    onError: (error: unknown) => toast.error(parseApiError(error).message),
  });
}

export function useUpdateSettingsBatch() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (updates: Array<{ id: string; value: string }>) =>
      adminSettingsApi.updateBatch(updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: settingsKeys.all() });
      toast.success("Settings saved");
    },
    onError: (error: unknown) => toast.error(parseApiError(error).message),
  });
}

export function useResetSettings() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (category?: string) =>
      adminSettingsApi.resetToDefaults(category),
    onSuccess: (_, category) => {
      queryClient.invalidateQueries({ queryKey: settingsKeys.all() });
      toast.success(
        category ? `${category} settings reset to defaults` : "All settings reset",
      );
    },
    onError: (error: unknown) => toast.error(parseApiError(error).message),
  });
}
