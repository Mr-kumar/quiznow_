import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { adminSubjectsApi } from "@/api/subjects";
import { subjectKeys } from "@/api/query-keys";
import { parseApiError } from "@/lib/errors";
import { unwrap } from "@/lib/unwrap";
import type { Subject, Topic } from "@/api/subjects";

interface UseSubjectsParams {
  page?: number;
  limit?: number;
  search?: string;
}

// ─── Subjects ─────────────────────────────────────────────────────────────────

export function useSubjects(params: UseSubjectsParams = {}) {
  const { page = 1, limit = 10, search = "" } = params;

  return useQuery({
    queryKey: subjectKeys.list({ page, limit, search }),
    queryFn: async () =>
      unwrap<{ data: Subject[]; total: number; page: number; limit: number }>(
        await adminSubjectsApi.getAll(page, limit, search || undefined),
      ),
    placeholderData: (prev) => prev,
    staleTime: 1000 * 60 * 5,
  });
}

export function useSubject(id: string) {
  return useQuery({
    queryKey: subjectKeys.detail(id),
    queryFn: async () => unwrap<Subject>(await adminSubjectsApi.getById(id)),
    enabled: !!id,
    staleTime: 1000 * 60 * 10,
  });
}

export function useCreateSubject() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: { name: string; isActive?: boolean }) =>
      adminSubjectsApi.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: subjectKeys.lists() });
      toast.success("Subject created");
    },
    onError: (error: unknown) => toast.error(parseApiError(error).message),
  });
}

export function useUpdateSubject() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      id,
      data,
    }: {
      id: string;
      data: { name?: string; isActive?: boolean };
    }) => adminSubjectsApi.update(id, data),
    onSuccess: (_, { id }) => {
      queryClient.invalidateQueries({ queryKey: subjectKeys.lists() });
      queryClient.invalidateQueries({ queryKey: subjectKeys.detail(id) });
      toast.success("Subject updated");
    },
    onError: (error: unknown) => toast.error(parseApiError(error).message),
  });
}

export function useDeleteSubject() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id: string) => adminSubjectsApi.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: subjectKeys.lists() });
      toast.success("Subject deleted");
    },
    onError: (error: unknown) => toast.error(parseApiError(error).message),
  });
}

// ─── Topics ───────────────────────────────────────────────────────────────────

export function useTopics(subjectId: string, params: UseSubjectsParams = {}) {
  const { page = 1, limit = 100, search = "" } = params;

  return useQuery({
    queryKey: subjectKeys.topics(subjectId),
    queryFn: async () =>
      unwrap<{ data: Topic[]; total: number }>(
        await adminSubjectsApi.getTopics(
          subjectId,
          page,
          limit,
          search || undefined,
        ),
      ),
    enabled: !!subjectId,
    staleTime: 1000 * 60 * 3,
  });
}

export function useCreateTopic() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      subjectId,
      data,
    }: {
      subjectId: string;
      data: { name: string; parentId?: string };
    }) => adminSubjectsApi.createTopic(subjectId, data),
    onSuccess: (_, { subjectId }) => {
      queryClient.invalidateQueries({ queryKey: subjectKeys.topics(subjectId) });
      toast.success("Topic created");
    },
    onError: (error: unknown) => toast.error(parseApiError(error).message),
  });
}

export function useUpdateTopic() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      subjectId,
      topicId,
      data,
    }: {
      subjectId: string;
      topicId: string;
      data: { name?: string; parentId?: string };
    }) => adminSubjectsApi.updateTopic(subjectId, topicId, data),
    onSuccess: (_, { subjectId }) => {
      queryClient.invalidateQueries({ queryKey: subjectKeys.topics(subjectId) });
      toast.success("Topic updated");
    },
    onError: (error: unknown) => toast.error(parseApiError(error).message),
  });
}

export function useDeleteTopic() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      subjectId,
      topicId,
    }: {
      subjectId: string;
      topicId: string;
    }) => adminSubjectsApi.deleteTopic(subjectId, topicId),
    onSuccess: (_, { subjectId }) => {
      queryClient.invalidateQueries({ queryKey: subjectKeys.topics(subjectId) });
      toast.success("Topic deleted");
    },
    onError: (error: unknown) => toast.error(parseApiError(error).message),
  });
}
