import api from "@/lib/api";
import type { ApiResponse, PaginatedResponse } from "@/types/api";

export interface Subscription {
  id: string;
  userId: string;
  planId: string;
  status: "ACTIVE" | "EXPIRED" | "CANCELLED";
  startsAt: string; // Server-assigned on create
  endsAt: string; // Server-computed from planId.durationDays
  createdAt: string;
  updatedAt: string;
  user?: {
    id: string;
    email: string;
    name?: string;
  };
  plan?: {
    id: string;
    name: string;
    price: number;
    durationDays: number;
  };
}

// Minimal create payload — server computes startsAt/endsAt from planId
export interface CreateSubscriptionRequest {
  userId: string;
  planId: string;
}

export interface UpdateSubscriptionRequest {
  status?: "ACTIVE" | "EXPIRED" | "CANCELLED";
}

export const adminSubscriptionsApi = {
  getAll: (page = 1, limit = 10, search?: string, status?: string) =>
    api.get<PaginatedResponse<Subscription>>("/admin/subscriptions", {
      params: { page, limit, search, status },
    }),
  getById: (id: string) =>
    api.get<ApiResponse<Subscription>>(`/admin/subscriptions/${id}`),
  create: (data: CreateSubscriptionRequest) =>
    api.post<ApiResponse<Subscription>>("/admin/subscriptions", data),
  update: (id: string, data: UpdateSubscriptionRequest) =>
    api.patch<ApiResponse<Subscription>>(`/admin/subscriptions/${id}`, data),
  cancel: (id: string) =>
    api.patch<ApiResponse<Subscription>>(
      `/admin/subscriptions/${id}/cancel`,
      {},
    ),
  extend: (id: string, days: number) =>
    api.patch<ApiResponse<Subscription>>(`/admin/subscriptions/${id}/extend`, {
      days,
    }),
  delete: (id: string) =>
    api.delete<ApiResponse<void>>(`/admin/subscriptions/${id}`),
};
