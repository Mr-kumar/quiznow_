import api from "@/lib/api";
import type { ApiResponse } from "@/types/api";

export interface AppSettings {
  id: string;
  key: string;
  value: string;
  description?: string;
  category: string;
  updatedAt: string;
}

export const adminSettingsApi = {
  getAll: () => api.get<ApiResponse<AppSettings[]>>("/admin/settings"),

  getByCategory: (category: string) =>
    api.get<ApiResponse<AppSettings[]>>(`/admin/settings/category/${category}`),

  update: (id: string, value: string) =>
    api.patch<ApiResponse<AppSettings>>(`/admin/settings/${id}`, { value }),

  /**
   * Batch update — runs all updates in parallel.
   * Added because settings/page.tsx calls this but the method was missing.
   */
  updateBatch: (updates: Array<{ id: string; value: string }>) =>
    Promise.all(
      updates.map(({ id, value }) =>
        api.patch<ApiResponse<AppSettings>>(`/admin/settings/${id}`, { value }),
      ),
    ),

  resetToDefaults: (category?: string) =>
    api.post<ApiResponse<void>>("/admin/settings/reset", { category }),
};
