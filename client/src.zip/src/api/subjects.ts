import api from "@/lib/api";
import type { ApiResponse, PaginatedResponse } from "@/types/api";
import type { Subject, Topic } from "@/types/subjects";

export type { Subject, Topic };

export const adminSubjectsApi = {
  getAll: (page = 1, limit = 10, search?: string) =>
    api.get<PaginatedResponse<Subject>>("/admin/subjects", {
      params: { page, limit, search },
    }),
  getById: (id: string) =>
    api.get<ApiResponse<Subject>>(`/admin/subjects/${id}`),
  create: (subjectData: { name: string; isActive?: boolean }) =>
    api.post<ApiResponse<Subject>>("/admin/subjects", subjectData),
  update: (id: string, subjectData: { name?: string; isActive?: boolean }) =>
    api.patch<ApiResponse<Subject>>(`/admin/subjects/${id}`, subjectData),
  delete: (id: string) =>
    api.delete<ApiResponse<void>>(`/admin/subjects/${id}`),

  // Topics
  getTopics: (subjectId: string, page = 1, limit = 10, search?: string) =>
    api.get<PaginatedResponse<Topic>>(`/admin/subjects/${subjectId}/topics`, {
      params: { page, limit, search },
    }),
  createTopic: (
    subjectId: string,
    topicData: { name: string; parentId?: string },
  ) =>
    api.post<ApiResponse<Topic>>(
      `/admin/subjects/${subjectId}/topics`,
      topicData,
    ),
  updateTopic: (
    subjectId: string,
    topicId: string,
    topicData: { name?: string; parentId?: string },
  ) =>
    api.patch<ApiResponse<Topic>>(
      `/admin/subjects/${subjectId}/topics/${topicId}`,
      topicData,
    ),
  deleteTopic: (subjectId: string, topicId: string) =>
    api.delete<ApiResponse<void>>(
      `/admin/subjects/${subjectId}/topics/${topicId}`,
    ),
};
