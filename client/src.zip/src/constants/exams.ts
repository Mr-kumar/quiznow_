export interface ExamCategory {
  id: string;
  label: string;
  shortLabel: string;
  emoji: string;
  tagline: string;
  color: string;
  lightBg: string;
  darkBg: string;
  navbarBg: string;
  dashboardColor: string;
  border: string;
  accent: string;
  count: string;
  students: string;
  subs: string[];
  highlights: string[];
}

export const EXAM_CATEGORIES: ExamCategory[] = [
  {
    id: "upsc",
    label: "UPSC / Civil Services",
    shortLabel: "UPSC",
    emoji: "🏛️",
    tagline: "India's most prestigious civil services examination",
    color: "from-amber-500 to-orange-500",
    lightBg: "bg-gradient-to-br from-amber-50 to-orange-50",
    darkBg: "dark:from-amber-950/40 dark:to-orange-950/40",
    navbarBg: "bg-amber-50 dark:bg-amber-950/30",
    dashboardColor:
      "bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-300",
    border: "border-amber-200 dark:border-amber-800",
    accent: "text-amber-600 dark:text-amber-400",
    count: "250+",
    students: "2.1L+",
    subs: ["CSE Prelims", "CSE Mains", "IFoS", "CDS", "NDA", "CAPF"],
    highlights: [
      "Bilingual Hindi/English",
      "PYQ 2013–2024",
      "Expert solutions",
    ],
  },
  {
    id: "ssc",
    label: "SSC Exams",
    shortLabel: "SSC",
    emoji: "📋",
    tagline: "Staff Selection Commission — government job gateway",
    color: "from-blue-500 to-cyan-500",
    lightBg: "bg-gradient-to-br from-blue-50 to-cyan-50",
    darkBg: "dark:from-blue-950/40 dark:to-cyan-950/40",
    navbarBg: "bg-blue-50 dark:bg-blue-950/30",
    dashboardColor:
      "bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300",
    border: "border-blue-200 dark:border-blue-800",
    accent: "text-blue-600 dark:text-blue-400",
    count: "300+",
    students: "4.8L+",
    subs: ["CGL Tier 1", "CGL Tier 2", "CHSL", "MTS", "GD Constable", "CPO"],
    highlights: [
      "Tier-1 & Tier-2 both",
      "Topic-wise practice",
      "Sectional tests",
    ],
  },
  {
    id: "banking",
    label: "Banking & Finance",
    shortLabel: "Banking",
    emoji: "🏦",
    tagline: "SBI, IBPS, RBI — unlock banking career opportunities",
    color: "from-green-500 to-emerald-500",
    lightBg: "bg-gradient-to-br from-green-50 to-emerald-50",
    darkBg: "dark:from-green-950/40 dark:to-emerald-950/40",
    navbarBg: "bg-green-50 dark:bg-green-950/30",
    dashboardColor:
      "bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300",
    border: "border-green-200 dark:border-green-800",
    accent: "text-green-600 dark:text-green-400",
    count: "200+",
    students: "5.3L+",
    subs: [
      "SBI PO",
      "SBI Clerk",
      "IBPS PO",
      "IBPS Clerk",
      "RBI Grade B",
      "NABARD",
    ],
    highlights: ["Memory-based papers", "Static GK capsules", "Interview prep"],
  },
  {
    id: "railways",
    label: "Railways",
    shortLabel: "Railways",
    emoji: "🚆",
    tagline: "RRB exams — India's largest employer",
    color: "from-indigo-500 to-purple-500",
    lightBg: "bg-gradient-to-br from-indigo-50 to-purple-50",
    darkBg: "dark:from-indigo-950/40 dark:to-purple-950/40",
    navbarBg: "bg-indigo-50 dark:bg-indigo-950/30",
    dashboardColor:
      "bg-indigo-100 dark:bg-indigo-900/30 text-indigo-800 dark:text-indigo-300",
    border: "border-indigo-200 dark:border-indigo-800",
    accent: "text-indigo-600 dark:text-indigo-400",
    count: "150+",
    students: "3.7L+",
    subs: ["RRB NTPC", "Group D", "ALP", "RRB JE", "RPF Constable", "RPF SI"],
    highlights: ["CBT 1 & CBT 2", "Technical sections", "Current affairs"],
  },
  {
    id: "neet",
    label: "NEET / Medical",
    shortLabel: "NEET",
    emoji: "🩺",
    tagline: "NEET UG & PG — your path to a medical career",
    color: "from-rose-500 to-pink-500",
    lightBg: "bg-gradient-to-br from-rose-50 to-pink-50",
    darkBg: "dark:from-rose-950/40 dark:to-pink-950/40",
    navbarBg: "bg-rose-50 dark:bg-rose-950/30",
    dashboardColor:
      "bg-rose-100 dark:bg-rose-900/30 text-rose-800 dark:text-rose-300",
    border: "border-rose-200 dark:border-rose-800",
    accent: "text-rose-600 dark:text-rose-400",
    count: "120+",
    students: "1.9L+",
    subs: ["NEET UG", "NEET PG", "AIIMS", "JIPMER", "DNB CET", "INI-CET"],
    highlights: [
      "NTA pattern exact",
      "Bio/Chem/Physics sections",
      "Negative marking",
    ],
  },
  {
    id: "jee",
    label: "JEE / Engineering",
    shortLabel: "JEE",
    emoji: "⚙️",
    tagline: "JEE Main, Advanced, GATE — engineering excellence",
    color: "from-violet-500 to-purple-600",
    lightBg: "bg-gradient-to-br from-violet-50 to-purple-50",
    darkBg: "dark:from-violet-950/40 dark:to-purple-950/40",
    navbarBg: "bg-violet-50 dark:bg-violet-950/30",
    dashboardColor:
      "bg-violet-100 dark:bg-violet-900/30 text-violet-800 dark:text-violet-300",
    border: "border-violet-200 dark:border-violet-800",
    accent: "text-violet-600 dark:text-violet-400",
    count: "180+",
    students: "2.6L+",
    subs: ["JEE Main", "JEE Advanced", "GATE", "BITSAT", "VITEEE", "MHT CET"],
    highlights: ["NTA shift-wise papers", "Formula sheets", "Rank predictor"],
  },
  {
    id: "defence",
    label: "Defence",
    shortLabel: "Defence",
    emoji: "🛡️",
    tagline: "NDA, CDS, AFCAT — serve the nation",
    color: "from-slate-500 to-zinc-600",
    lightBg: "bg-gradient-to-br from-slate-50 to-zinc-50",
    darkBg: "dark:from-slate-950/40 dark:to-zinc-950/40",
    navbarBg: "bg-slate-50 dark:bg-slate-950/30",
    dashboardColor:
      "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200",
    border: "border-slate-200 dark:border-slate-700",
    accent: "text-slate-600 dark:text-slate-400",
    count: "90+",
    students: "98K+",
    subs: ["NDA", "CDS", "AFCAT", "MNS", "Agniveer Army", "Agniveer Navy"],
    highlights: [
      "GAT & Math sections",
      "SSB interview tips",
      "Physical standards",
    ],
  },
  {
    id: "state",
    label: "State PSC",
    shortLabel: "State PSC",
    emoji: "🗺️",
    tagline: "BPSC, UPPSC, MPSC and all state-level exams",
    color: "from-teal-500 to-cyan-500",
    lightBg: "bg-gradient-to-br from-teal-50 to-cyan-50",
    darkBg: "dark:from-teal-950/40 dark:to-cyan-950/40",
    navbarBg: "bg-teal-50 dark:bg-teal-950/30",
    dashboardColor:
      "bg-teal-100 dark:bg-teal-900/30 text-teal-800 dark:text-teal-300",
    border: "border-teal-200 dark:border-teal-800",
    accent: "text-teal-600 dark:text-teal-400",
    count: "400+",
    students: "6.1L+",
    subs: ["BPSC 70th", "UPPSC PCS", "MPSC", "MPPSC", "RPSC RAS", "JPSC"],
    highlights: [
      "State-specific GK",
      "Regional language support",
      "District cut-offs",
    ],
  },
];
