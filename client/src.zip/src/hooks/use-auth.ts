import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuthStore } from "../stores/auth-store";
import api from "../lib/api";

interface LoginCredentials {
  email: string;
  password: string;
}

interface LoginResponse {
  user: {
    id: string;
    email: string;
    name: string;
    role: "ADMIN" | "STUDENT";
  };
  token: string;
  expiresIn: number;
}

// Hook for user login
export function useLogin() {
  const { login } = useAuthStore();

  return useMutation({
    mutationFn: async (
      credentials: LoginCredentials,
    ): Promise<LoginResponse> => {
      const response = await api.post<LoginResponse>(
        "/auth/login",
        credentials,
      );
      return response.data;
    },
    onSuccess: (data) => {
      login(data.user, data.token, data.expiresIn);
    },
    onError: (error: any) => {
      console.error("Login failed:", error.response?.data || error.message);
    },
  });
}

// Hook for user logout
export function useLogout() {
  const { logout } = useAuthStore();

  return useMutation({
    mutationFn: async () => {
      await api.post("/auth/logout");
    },
    onSuccess: () => {
      logout();
    },
    onError: (error: any) => {
      console.error("Logout failed:", error.response?.data || error.message);
      logout(); // still logout locally even if server call fails
    },
  });
}

// Hook for getting current user profile
export function useCurrentUser() {
  const { isAuthenticated, token } = useAuthStore();

  return useQuery({
    queryKey: ["currentUser"],
    queryFn: async () => {
      const response = await api.get("/auth/me");
      return response.data;
    },
    enabled: isAuthenticated && !!token,
    staleTime: 1000 * 60 * 5,
    retry: false,
  });
}

// Hook for refreshing token
export function useRefreshToken() {
  return useMutation({
    mutationFn: async () => {
      const response = await api.post<{ token: string; expiresIn: number }>(
        "/auth/refresh",
      );
      return response.data;
    },
    onSuccess: (data) => {
      // FIXED: actually save the new token to the store.
      // Previously called refreshToken() which only checked expiry — never persisted new token.
      const { user, login } = useAuthStore.getState();
      if (user) {
        login(user, data.token, data.expiresIn);
      }
    },
    onError: (error: any) => {
      console.error(
        "Token refresh failed:",
        error.response?.data || error.message,
      );
      // Force logout if refresh fails — token is unrecoverable
      useAuthStore.getState().logout();
    },
  });
}
